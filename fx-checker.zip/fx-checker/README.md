# FX Checker

A live foreign exchange app built with React + Tailwind CSS.  
Final project for ProjectCode Hijabi — built using starter assets from Frontend Mentor.

---

## Tech Stack

- React (Create React App)
- Tailwind CSS
- Frankfurter API (free, no API key needed — powered by ECB data)

---

## Features

- **Live ticker** — scrolling rate strip for popular currency pairs
- **Converter** — amount input, searchable currency picker with flags, swap button
- **Rate History chart** — SVG line chart with 1W / 1M / 3M / 1Y / 5Y range tabs
- **Compare tab** — 1 base currency vs. multiple currencies in a table
- **Favorites** — pin pairs with the star button, persisted to localStorage
- **Conversion Log** — tap "Log conversion" to save a record, persisted to localStorage
- Responsive: works on mobile and desktop

---

## Setup

```bash
# 1. Install dependencies
npm install

# 2. Run the dev server
npm start

# Your app runs at http://localhost:3000
```

## Build for submission

```bash
npm run build
```

Then deploy the `build/` folder to Netlify or Vercel.

---

## Project structure

```
src/
  App.js                   # Root component, shared state, tab switching
  index.js                 # React entry point
  index.css                # Tailwind base + custom animations
  api.js                   # All fetch calls to Frankfurter API
  data/
    currencies.js          # Currency info, flag helpers
  hooks/
    useLocalStorage.js     # localStorage persistence hook
  components/
    Header.js              # Logo + subtitle
    Ticker.js              # Scrolling live markets strip
    Converter.js           # Main converter UI
    CurrencyPicker.js      # Searchable currency dropdown
    RateHistory.js         # SVG chart + date range tabs
    Compare.js             # Multi-currency comparison table
    Favorites.js           # Saved currency pairs
    ConversionLog.js       # History of logged conversions
```
