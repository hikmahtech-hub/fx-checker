/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./public/index.html", "./src/**/*.{js,jsx}"],
  theme: {
    extend: {
      colors: {
        bg: "#0E0E12",
        surface: "#17171D",
        surfaceAlt: "#1F1F27",
        border: "#2A2A33",
        primary: "#7C5CFC",
        text: "#F2F2F5",
        muted: "#8C8C99",
        up: "#34C77B",
        down: "#F25C5C",
      },
      fontFamily: {
        mono: ["JetBrains Mono", "monospace"],
      },
    },
  },
  plugins: [],
};
