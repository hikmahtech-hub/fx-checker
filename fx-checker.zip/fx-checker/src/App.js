import React, { useState } from "react";
import Header from "./components/Header";
import Ticker from "./components/Ticker";
import Converter from "./components/Converter";
import RateHistory from "./components/RateHistory";
import Compare from "./components/Compare";
import Favorites from "./components/Favorites";
import ConversionLog from "./components/ConversionLog";
import { useLocalStorage } from "./hooks/useLocalStorage";

const TABS = ["History", "Compare", "Favorites", "Log"];

function App() {
  // Core converter state
  const [sendAmount, setSendAmount] = useState("100");
  const [fromCurrency, setFromCurrency] = useState("USD");
  const [toCurrency, setToCurrency] = useState("EUR");

  // Tab
  const [activeTab, setActiveTab] = useLocalStorage("fx-activeTab", "History");

  // Favorites: array of { from, to }
  const [favorites, setFavorites] = useLocalStorage("fx-favorites", []);

  // Conversion log: array of { from, to, sendAmount, receiveAmount, timestamp }
  const [conversionLog, setConversionLog] = useLocalStorage("fx-log", []);

  // --- Favorites helpers ---
  const pairKey = `${fromCurrency}-${toCurrency}`;

  const isFavorite = favorites.some(
    (f) => f.from === fromCurrency && f.to === toCurrency
  );

  function handleToggleFavorite() {
    if (isFavorite) {
      setFavorites((prev) =>
        prev.filter((f) => !(f.from === fromCurrency && f.to === toCurrency))
      );
    } else {
      setFavorites((prev) => [...prev, { from: fromCurrency, to: toCurrency }]);
    }
  }

  function handleRemoveFavorite(key) {
    const [from, to] = key.split("-");
    setFavorites((prev) => prev.filter((f) => !(f.from === from && f.to === to)));
  }

  function handleSelectFavoritePair(from, to) {
    setFromCurrency(from);
    setToCurrency(to);
    setActiveTab("History");
  }

  // --- Conversion log helpers ---
  function handleLogConversion(entry) {
    setConversionLog((prev) => [...prev, entry]);
  }

  function handleClearLog() {
    setConversionLog([]);
  }

  return (
    <div className="min-h-screen bg-bg text-text font-mono">
      <Header />
      <Ticker />

      <main className="max-w-4xl mx-auto px-4 sm:px-6 py-6 space-y-4">

        {/* Converter always visible at top */}
        <Converter
          sendAmount={sendAmount}
          setSendAmount={setSendAmount}
          fromCurrency={fromCurrency}
          setFromCurrency={setFromCurrency}
          toCurrency={toCurrency}
          setToCurrency={setToCurrency}
          isFavorite={isFavorite}
          onToggleFavorite={handleToggleFavorite}
          onLogConversion={handleLogConversion}
        />

        {/* Tabs */}
        <div
          role="tablist"
          aria-label="Rate information tabs"
          className="flex gap-1 bg-surface border border-border rounded-xl p-1"
        >
          {TABS.map((tab) => (
            <button
              key={tab}
              role="tab"
              aria-selected={activeTab === tab}
              type="button"
              onClick={() => setActiveTab(tab)}
              className={`flex-1 py-2 text-sm font-medium rounded-lg transition ${
                activeTab === tab
                  ? "bg-primary text-white"
                  : "text-muted hover:text-text"
              }`}
            >
              {tab}
              {tab === "Favorites" && favorites.length > 0 && (
                <span className="ml-1 text-xs opacity-70">({favorites.length})</span>
              )}
              {tab === "Log" && conversionLog.length > 0 && (
                <span className="ml-1 text-xs opacity-70">({conversionLog.length})</span>
              )}
            </button>
          ))}
        </div>

        {/* Tab panels */}
        {activeTab === "History" && (
          <RateHistory fromCurrency={fromCurrency} toCurrency={toCurrency} />
        )}
        {activeTab === "Compare" && (
          <Compare baseCurrency={fromCurrency} />
        )}
        {activeTab === "Favorites" && (
          <Favorites
            favorites={favorites}
            onRemove={handleRemoveFavorite}
            onSelectPair={handleSelectFavoritePair}
          />
        )}
        {activeTab === "Log" && (
          <ConversionLog log={conversionLog} onClearLog={handleClearLog} />
        )}
      </main>

      <footer className="text-center py-6 text-xs text-muted border-t border-border mt-4">
        Data from{" "}
        <a
          href="https://www.frankfurter.app"
          target="_blank"
          rel="noopener noreferrer"
          className="text-primary hover:underline"
        >
          Frankfurter (ECB)
        </a>{" "}
        &middot; End of day rates &middot; Challenge by{" "}
        <a
          href="https://www.frontendmentor.io"
          target="_blank"
          rel="noopener noreferrer"
          className="text-primary hover:underline"
        >
          Frontend Mentor
        </a>
      </footer>
    </div>
  );
}

export default App;
