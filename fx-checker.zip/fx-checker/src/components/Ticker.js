import React, { useEffect, useState } from "react";
import { POPULAR_CODES, flagUrl } from "../data/currencies";

const BASE_URL = "https://api.frankfurter.app";

function Ticker() {
  const [pairs, setPairs] = useState([]);
  const [error, setError] = useState(false);

  useEffect(() => {
    async function loadTicker() {
      try {
        const [latestRes, pastRes] = await Promise.all([
          fetch(`${BASE_URL}/latest?from=USD`),
          fetch(`${BASE_URL}/${pastDate()}?from=USD`),
        ]);
        if (!latestRes.ok || !pastRes.ok) throw new Error("ticker failed");
        const latest = await latestRes.json();
        const past = await pastRes.json();

        const rows = POPULAR_CODES.filter((code) => code !== "USD").map((code) => {
          const current = latest.rates[code];
          const previous = past.rates[code];
          const change = previous ? ((current - previous) / previous) * 100 : 0;
          return { code, rate: current, change };
        });
        setPairs(rows);
      } catch {
        setError(true);
      }
    }
    loadTicker();
  }, []);

  if (error || pairs.length === 0) return null;

  // duplicate the list so the CSS scroll animation loops seamlessly
  const looped = [...pairs, ...pairs];

  return (
    <div className="bg-surface border-b border-border overflow-hidden py-2">
      <div className="flex items-center gap-2 px-4 mb-1">
        <span className="text-xs uppercase tracking-wide text-muted">Live markets</span>
      </div>
      <div className="overflow-hidden">
        <div className="flex gap-8 animate-ticker w-max px-4">
          {looped.map((pair, i) => (
            <div key={`${pair.code}-${i}`} className="flex items-center gap-2 text-sm whitespace-nowrap">
              {flagUrl(pair.code) && (
                <img src={flagUrl(pair.code)} alt="" className="w-4 h-4 rounded-full object-cover" />
              )}
              <span className="font-medium">USD/{pair.code}</span>
              <span className="text-muted">{pair.rate.toFixed(4)}</span>
              <span className={pair.change >= 0 ? "text-up" : "text-down"}>
                {pair.change >= 0 ? "▲" : "▼"} {Math.abs(pair.change).toFixed(2)}%
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function pastDate() {
  const d = new Date();
  d.setDate(d.getDate() - 3); // a few days back to be safe for weekends/bank holidays
  return d.toISOString().slice(0, 10);
}

export default Ticker;
