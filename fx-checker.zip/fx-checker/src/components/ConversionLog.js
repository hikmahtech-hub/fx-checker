import React from "react";
import { flagUrl } from "../data/currencies";

function ConversionLog({ log, onClearLog }) {
  if (log.length === 0) {
    return (
      <section className="bg-surface border border-border rounded-2xl p-6 text-center">
        <img
          src={`${process.env.PUBLIC_URL}/assets/images/icon-exchange.svg`}
          alt=""
          className="w-8 h-8 mx-auto mb-3 opacity-40"
        />
        <p className="text-muted text-sm">
          No conversions logged yet. Hit "Log conversion" after converting to save a record here.
        </p>
      </section>
    );
  }

  return (
    <section className="bg-surface border border-border rounded-2xl p-4 sm:p-6">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-lg font-semibold">Conversion Log</h2>
        <button
          type="button"
          onClick={onClearLog}
          className="flex items-center gap-1 text-xs text-muted hover:text-down transition"
        >
          <img
            src={`${process.env.PUBLIC_URL}/assets/images/icon-delete-filled.svg`}
            alt=""
            className="w-4 h-4"
          />
          Clear all
        </button>
      </div>

      <ul className="space-y-2">
        {[...log].reverse().map((entry, i) => {
          const date = new Date(entry.timestamp);
          const dateStr = date.toLocaleDateString(undefined, {
            day: "2-digit",
            month: "short",
            year: "numeric",
          });
          const timeStr = date.toLocaleTimeString(undefined, {
            hour: "2-digit",
            minute: "2-digit",
          });

          return (
            <li
              key={i}
              className="flex items-center gap-3 bg-surfaceAlt border border-border rounded-xl px-4 py-3"
            >
              {/* Flags */}
              <div className="flex -space-x-1 flex-shrink-0">
                {flagUrl(entry.from) && (
                  <img
                    src={flagUrl(entry.from)}
                    alt={entry.from}
                    className="w-6 h-6 rounded-full object-cover ring-1 ring-surface"
                  />
                )}
                {flagUrl(entry.to) && (
                  <img
                    src={flagUrl(entry.to)}
                    alt={entry.to}
                    className="w-6 h-6 rounded-full object-cover ring-1 ring-surface"
                  />
                )}
              </div>

              {/* Conversion text */}
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium">
                  {entry.sendAmount.toLocaleString()} {entry.from}{" "}
                  <img
                    src={`${process.env.PUBLIC_URL}/assets/images/icon-arrow-right.svg`}
                    alt="→"
                    className="inline w-3 h-3 mx-1 opacity-60"
                  />
                  {entry.receiveAmount.toFixed(2)} {entry.to}
                </p>
                <p className="text-xs text-muted mt-0.5">
                  {dateStr} at {timeStr}
                </p>
              </div>
            </li>
          );
        })}
      </ul>
    </section>
  );
}

export default ConversionLog;
