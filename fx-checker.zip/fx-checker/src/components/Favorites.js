import React from "react";
import { flagUrl } from "../data/currencies";

function Favorites({ favorites, onRemove, onSelectPair }) {
  if (favorites.length === 0) {
    return (
      <section className="bg-surface border border-border rounded-2xl p-6 text-center">
        <img
          src={`${process.env.PUBLIC_URL}/assets/images/icon-star.svg`}
          alt=""
          className="w-8 h-8 mx-auto mb-3 opacity-40"
        />
        <p className="text-muted text-sm">
          No favorites yet. Star a currency pair in the converter to save it here.
        </p>
      </section>
    );
  }

  return (
    <section className="bg-surface border border-border rounded-2xl p-4 sm:p-6">
      <h2 className="text-lg font-semibold mb-4">Favorite Pairs</h2>
      <ul className="space-y-2">
        {favorites.map((pair) => {
          const key = `${pair.from}-${pair.to}`;
          return (
            <li
              key={key}
              className="flex items-center gap-3 bg-surfaceAlt border border-border rounded-xl px-4 py-3"
            >
              {/* Flags */}
              <div className="flex -space-x-1">
                {flagUrl(pair.from) && (
                  <img
                    src={flagUrl(pair.from)}
                    alt={pair.from}
                    className="w-6 h-6 rounded-full object-cover ring-1 ring-surface"
                  />
                )}
                {flagUrl(pair.to) && (
                  <img
                    src={flagUrl(pair.to)}
                    alt={pair.to}
                    className="w-6 h-6 rounded-full object-cover ring-1 ring-surface"
                  />
                )}
              </div>

              {/* Pair label */}
              <span className="font-medium flex-1">
                {pair.from}{" "}
                <img
                  src={`${process.env.PUBLIC_URL}/assets/images/icon-arrow-right.svg`}
                  alt="to"
                  className="inline w-3 h-3 mx-1 opacity-60"
                />
                {pair.to}
              </span>

              {/* Actions */}
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => onSelectPair(pair.from, pair.to)}
                  className="text-xs text-primary hover:underline"
                >
                  View rate
                </button>
                <button
                  type="button"
                  onClick={() => onRemove(key)}
                  aria-label={`Remove ${pair.from}/${pair.to} from favorites`}
                  className="opacity-50 hover:opacity-100 transition"
                >
                  <img
                    src={`${process.env.PUBLIC_URL}/assets/images/icon-delete.svg`}
                    alt=""
                    className="w-4 h-4"
                  />
                </button>
              </div>
            </li>
          );
        })}
      </ul>
    </section>
  );
}

export default Favorites;
