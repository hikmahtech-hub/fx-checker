import React, { useState, useEffect } from "react";
import { fetchLatestRates } from "../api";
import { CURRENCY_INFO, flagUrl } from "../data/currencies";

const ALL_CODES = Object.keys(CURRENCY_INFO);

function Compare({ baseCurrency }) {
  const [rates, setRates] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [selected, setSelected] = useState(["EUR", "GBP", "JPY", "CAD"]);

  useEffect(() => {
    async function load() {
      setLoading(true);
      setError("");
      try {
        const data = await fetchLatestRates(baseCurrency);
        setRates(data.rates);
      } catch (err) {
        setError(err.message || "Could not load rates.");
        setRates(null);
      } finally {
        setLoading(false);
      }
    }
    load();
  }, [baseCurrency]);

  function toggleCurrency(code) {
    setSelected((prev) =>
      prev.includes(code) ? prev.filter((c) => c !== code) : [...prev, code]
    );
  }

  const availableToCompare = ALL_CODES.filter((c) => c !== baseCurrency);

  return (
    <section className="bg-surface border border-border rounded-2xl p-4 sm:p-6">
      <h2 className="text-lg font-semibold mb-1">Compare Rates</h2>
      <p className="text-sm text-muted mb-4">
        Showing 1 {baseCurrency} against selected currencies
      </p>

      {/* Currency toggle pills */}
      <div className="flex flex-wrap gap-2 mb-5">
        {availableToCompare.map((code) => {
          const active = selected.includes(code);
          return (
            <button
              key={code}
              type="button"
              onClick={() => toggleCurrency(code)}
              className={`flex items-center gap-1 px-2 py-1 rounded-lg text-xs border transition ${
                active
                  ? "bg-primary border-primary text-white"
                  : "border-border text-muted hover:border-primary"
              }`}
            >
              {flagUrl(code) && (
                <img src={flagUrl(code)} alt="" className="w-3 h-3 rounded-full object-cover" />
              )}
              {code}
            </button>
          );
        })}
      </div>

      {/* Table */}
      {loading && <p className="text-muted text-sm">Loading rates…</p>}
      {error && <p className="text-down text-sm">{error}</p>}
      {!loading && !error && rates && (
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="text-left text-muted border-b border-border">
                <th className="pb-2 font-medium">Currency</th>
                <th className="pb-2 font-medium text-right">1 {baseCurrency} =</th>
              </tr>
            </thead>
            <tbody>
              {selected.length === 0 && (
                <tr>
                  <td colSpan={2} className="py-6 text-center text-muted">
                    Select currencies above to compare.
                  </td>
                </tr>
              )}
              {selected.map((code) => {
                const rate = rates[code];
                if (!rate) return null;
                return (
                  <tr key={code} className="border-b border-border last:border-0">
                    <td className="py-3">
                      <div className="flex items-center gap-2">
                        {flagUrl(code) && (
                          <img
                            src={flagUrl(code)}
                            alt=""
                            className="w-5 h-5 rounded-full object-cover"
                          />
                        )}
                        <span className="font-medium">{code}</span>
                        <span className="text-muted hidden sm:inline">
                          {CURRENCY_INFO[code]?.name}
                        </span>
                      </div>
                    </td>
                    <td className="py-3 text-right font-mono tabular-nums">
                      {rate.toFixed(4)}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </section>
  );
}

export default Compare;
