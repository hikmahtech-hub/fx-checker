import React, { useState, useEffect, useCallback } from "react";
import CurrencyPicker from "./CurrencyPicker";
import { flagUrl } from "../data/currencies";
import { fetchPairRate } from "../api";

function Converter({
  sendAmount,
  setSendAmount,
  fromCurrency,
  setFromCurrency,
  toCurrency,
  setToCurrency,
  isFavorite,
  onToggleFavorite,
  onLogConversion,
}) {
  const [rate, setRate] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [openPicker, setOpenPicker] = useState(null); // "from" | "to" | null
  const [announcement, setAnnouncement] = useState("");

  const loadRate = useCallback(async () => {
    setError("");
    setLoading(true);
    try {
      const r = await fetchPairRate(fromCurrency, toCurrency);
      setRate(r);
    } catch (err) {
      setError(err.message || "Could not load the exchange rate.");
      setRate(null);
    } finally {
      setLoading(false);
    }
  }, [fromCurrency, toCurrency]);

  useEffect(() => {
    loadRate();
  }, [loadRate]);

  const amountNumber = parseFloat(sendAmount) || 0;
  const receiveAmount = rate ? amountNumber * rate : null;

  function handleSwap() {
    setFromCurrency(toCurrency);
    setToCurrency(fromCurrency);
  }

  function handleSelect(currency) {
    if (openPicker === "from") setFromCurrency(currency);
    if (openPicker === "to") setToCurrency(currency);
    setOpenPicker(null);
  }

  function handleFavoriteClick() {
    onToggleFavorite();
    setAnnouncement(isFavorite ? "Removed from favorites" : "Pair favorited");
  }

  function handleLogClick() {
    if (!rate || !amountNumber) return;
    onLogConversion({
      from: fromCurrency,
      to: toCurrency,
      sendAmount: amountNumber,
      receiveAmount,
      timestamp: Date.now(),
    });
    setAnnouncement("Conversion logged");
  }

  return (
    <section className="bg-surface border border-border rounded-2xl p-4 sm:p-6 relative">
      <h2 className="text-lg font-semibold mb-4">Check the rate</h2>

      <div aria-live="polite" className="sr-only">
        {announcement}
      </div>

      {/* Send */}
      <div className="mb-3">
        <label htmlFor="send-amount" className="block text-xs uppercase tracking-wide text-muted mb-1">
          Send
        </label>
        <div className="flex gap-2">
          <input
            id="send-amount"
            type="number"
            min="0"
            value={sendAmount}
            onChange={(e) => setSendAmount(e.target.value)}
            className="flex-1 min-w-0 bg-surfaceAlt border border-border rounded-lg px-3 py-2 text-lg outline-none focus:border-primary"
          />
          <CurrencyButton
            code={fromCurrency}
            onClick={() => setOpenPicker(openPicker === "from" ? null : "from")}
          />
        </div>
        {openPicker === "from" && (
          <CurrencyPicker
            label="send"
            selected={fromCurrency}
            onSelect={handleSelect}
            onClose={() => setOpenPicker(null)}
          />
        )}
      </div>

      {/* Swap button */}
      <div className="flex justify-center my-1">
        <button
          type="button"
          onClick={handleSwap}
          aria-label="Swap send and receive currencies"
          className="bg-surfaceAlt border border-border rounded-full p-2 hover:border-primary transition"
        >
          <img
            src={`${process.env.PUBLIC_URL}/assets/images/icon-exchange-vertical.svg`}
            alt=""
            className="w-4 h-4"
          />
        </button>
      </div>

      {/* Receive */}
      <div className="mb-4">
        <label className="block text-xs uppercase tracking-wide text-muted mb-1">Receive</label>
        <div className="flex gap-2">
          <div className="flex-1 min-w-0 bg-surfaceAlt border border-border rounded-lg px-3 py-2 text-lg text-muted">
            {loading ? "…" : receiveAmount !== null ? receiveAmount.toFixed(2) : "—"}
          </div>
          <CurrencyButton
            code={toCurrency}
            onClick={() => setOpenPicker(openPicker === "to" ? null : "to")}
          />
        </div>
        {openPicker === "to" && (
          <CurrencyPicker
            label="receive"
            selected={toCurrency}
            onSelect={handleSelect}
            onClose={() => setOpenPicker(null)}
          />
        )}
      </div>

      {/* Rate / error state */}
      <div className="mb-4 min-h-[1.5rem]">
        {error && <p className="text-down text-sm">{error}</p>}
        {!error && rate && (
          <p className="text-sm text-muted">
            1 {fromCurrency} = {rate.toFixed(4)} {toCurrency}
          </p>
        )}
      </div>

      <div className="flex gap-2">
        <button
          type="button"
          onClick={handleFavoriteClick}
          className="flex items-center gap-1 border border-border rounded-lg px-3 py-2 text-sm hover:border-primary transition"
        >
          <img
            src={`${process.env.PUBLIC_URL}/assets/images/${
              isFavorite ? "icon-star-filled.svg" : "icon-star.svg"
            }`}
            alt=""
            className="w-4 h-4"
          />
          {isFavorite ? "Favorited" : "Favorite"}
        </button>
        <button
          type="button"
          onClick={handleLogClick}
          disabled={!rate || !amountNumber}
          className="flex-1 bg-primary text-white rounded-lg px-3 py-2 text-sm font-medium hover:opacity-90 transition disabled:opacity-50"
        >
          Log conversion
        </button>
      </div>
    </section>
  );
}

function CurrencyButton({ code, onClick }) {
  return (
    <button
      type="button"
      onClick={onClick}
      className="flex items-center gap-2 bg-surfaceAlt border border-border rounded-lg px-3 py-2 hover:border-primary transition"
    >
      {flagUrl(code) && (
        <img src={flagUrl(code)} alt="" className="w-5 h-5 rounded-full object-cover" />
      )}
      <span className="font-medium text-sm">{code}</span>
      <img
        src={`${process.env.PUBLIC_URL}/assets/images/icon-chevron-down.svg`}
        alt=""
        className="w-3 h-3"
      />
    </button>
  );
}

export default Converter;
