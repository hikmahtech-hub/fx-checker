import React, { useState, useEffect } from "react";
import { fetchHistory, startDateForRange, todayDateString } from "../api";

const RANGES = ["1w", "1m", "3m", "1y", "5y"];

function RateHistory({ fromCurrency, toCurrency }) {
  const [range, setRange] = useState("1m");
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    async function load() {
      setLoading(true);
      setError("");
      try {
        const start = startDateForRange(range);
        const end = todayDateString();
        const history = await fetchHistory(fromCurrency, toCurrency, start, end);
        setData(history);
      } catch (err) {
        setError(err.message || "Could not load history.");
        setData([]);
      } finally {
        setLoading(false);
      }
    }
    load();
  }, [fromCurrency, toCurrency, range]);

  const rates = data.map((d) => d.rate);
  const minRate = rates.length ? Math.min(...rates) : 0;
  const maxRate = rates.length ? Math.max(...rates) : 1;
  const rangeSpan = maxRate - minRate || 1;

  const firstRate = rates[0];
  const lastRate = rates[rates.length - 1];
  const overallChange = firstRate ? ((lastRate - firstRate) / firstRate) * 100 : 0;
  const isUp = overallChange >= 0;

  // Build SVG polyline points
  const WIDTH = 600;
  const HEIGHT = 120;
  const PADDING = 12;

  const points = data.map((point, i) => {
    const x = data.length < 2
      ? WIDTH / 2
      : PADDING + (i / (data.length - 1)) * (WIDTH - PADDING * 2);
    const y =
      HEIGHT - PADDING - ((point.rate - minRate) / rangeSpan) * (HEIGHT - PADDING * 2);
    return `${x},${y}`;
  });

  const polylinePoints = points.join(" ");

  return (
    <section className="bg-surface border border-border rounded-2xl p-4 sm:p-6">
      <div className="flex items-center justify-between mb-4 flex-wrap gap-2">
        <div>
          <h2 className="text-lg font-semibold">
            {fromCurrency} / {toCurrency} Rate History
          </h2>
          {!loading && !error && data.length > 0 && (
            <p className={`text-sm mt-0.5 ${isUp ? "text-up" : "text-down"}`}>
              {isUp ? "▲" : "▼"} {Math.abs(overallChange).toFixed(2)}% over period
            </p>
          )}
        </div>

        <div className="flex gap-1" role="group" aria-label="Date range">
          {RANGES.map((r) => (
            <button
              key={r}
              type="button"
              onClick={() => setRange(r)}
              className={`px-3 py-1 rounded-lg text-xs font-medium transition ${
                range === r
                  ? "bg-primary text-white"
                  : "text-muted hover:text-text hover:bg-surfaceAlt"
              }`}
            >
              {r.toUpperCase()}
            </button>
          ))}
        </div>
      </div>

      {/* Chart area */}
      <div className="w-full h-32 relative">
        {loading && (
          <div className="absolute inset-0 flex items-center justify-center text-muted text-sm">
            Loading chart…
          </div>
        )}
        {error && (
          <div className="absolute inset-0 flex items-center justify-center text-down text-sm">
            {error}
          </div>
        )}
        {!loading && !error && data.length > 1 && (
          <svg
            viewBox={`0 0 ${WIDTH} ${HEIGHT}`}
            className="w-full h-full"
            aria-label={`Exchange rate chart for ${fromCurrency}/${toCurrency}`}
          >
            {/* Gradient fill under the line */}
            <defs>
              <linearGradient id="chartGrad" x1="0" y1="0" x2="0" y2="1">
                <stop
                  offset="0%"
                  stopColor={isUp ? "#34C77B" : "#F25C5C"}
                  stopOpacity="0.25"
                />
                <stop
                  offset="100%"
                  stopColor={isUp ? "#34C77B" : "#F25C5C"}
                  stopOpacity="0"
                />
              </linearGradient>
            </defs>

            {/* Filled area */}
            <polygon
              points={`${points[0].split(",")[0]},${HEIGHT} ${polylinePoints} ${
                points[points.length - 1].split(",")[0]
              },${HEIGHT}`}
              fill="url(#chartGrad)"
            />

            {/* Line */}
            <polyline
              points={polylinePoints}
              fill="none"
              stroke={isUp ? "#34C77B" : "#F25C5C"}
              strokeWidth="2"
              strokeLinejoin="round"
              strokeLinecap="round"
            />
          </svg>
        )}
        {!loading && !error && data.length <= 1 && (
          <div className="absolute inset-0 flex items-center justify-center text-muted text-sm">
            Not enough data for this range.
          </div>
        )}
      </div>

      {/* Min / max labels */}
      {!loading && !error && data.length > 1 && (
        <div className="flex justify-between text-xs text-muted mt-1">
          <span>{data[0]?.date}</span>
          <span>
            Low {minRate.toFixed(4)} &nbsp;|&nbsp; High {maxRate.toFixed(4)}
          </span>
          <span>{data[data.length - 1]?.date}</span>
        </div>
      )}
    </section>
  );
}

export default RateHistory;
