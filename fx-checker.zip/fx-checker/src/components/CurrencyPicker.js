import React, { useState, useMemo, useRef, useEffect } from "react";
import { CURRENCY_INFO, POPULAR_CODES, flagUrl, currencyName } from "../data/currencies";

function CurrencyPicker({ selected, onSelect, onClose, label }) {
  const [query, setQuery] = useState("");
  const inputRef = useRef(null);

  useEffect(() => {
    inputRef.current?.focus();
  }, []);

  const allCodes = Object.keys(CURRENCY_INFO);
  const otherCodes = allCodes.filter((c) => !POPULAR_CODES.includes(c));

  const matches = (code) => {
    const q = query.trim().toLowerCase();
    if (!q) return true;
    return (
      code.toLowerCase().includes(q) ||
      currencyName(code).toLowerCase().includes(q)
    );
  };

  const filteredPopular = useMemo(() => POPULAR_CODES.filter(matches), [query]);
  const filteredOther = useMemo(() => otherCodes.filter(matches), [query]);

  function handleKeyDown(e) {
    if (e.key === "Escape") onClose();
  }

  return (
    <div
      role="dialog"
      aria-label={`Choose ${label} currency`}
      className="absolute z-20 mt-2 w-72 max-h-96 overflow-y-auto bg-surfaceAlt border border-border rounded-xl shadow-xl p-3"
      onKeyDown={handleKeyDown}
    >
      <div className="flex items-center gap-2 bg-surface border border-border rounded-lg px-3 py-2 mb-3">
        <img
          src={`${process.env.PUBLIC_URL}/assets/images/icon-search.svg`}
          alt=""
          className="w-4 h-4 opacity-60"
        />
        <input
          ref={inputRef}
          type="text"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Search currencies..."
          aria-label="Search currencies"
          className="bg-transparent outline-none text-sm w-full placeholder:text-muted"
        />
      </div>

      {filteredPopular.length > 0 && (
        <div className="mb-3">
          <p className="text-xs uppercase tracking-wide text-muted mb-1 px-1">
            Popular ({filteredPopular.length})
          </p>
          <ul role="listbox">
            {filteredPopular.map((code) => (
              <CurrencyRow
                key={code}
                code={code}
                selected={code === selected}
                onSelect={onSelect}
              />
            ))}
          </ul>
        </div>
      )}

      {filteredOther.length > 0 && (
        <div>
          <p className="text-xs uppercase tracking-wide text-muted mb-1 px-1">
            Other currencies ({filteredOther.length})
          </p>
          <ul role="listbox">
            {filteredOther.map((code) => (
              <CurrencyRow
                key={code}
                code={code}
                selected={code === selected}
                onSelect={onSelect}
              />
            ))}
          </ul>
        </div>
      )}

      {filteredPopular.length === 0 && filteredOther.length === 0 && (
        <p className="text-sm text-muted text-center py-4">No currencies match.</p>
      )}
    </div>
  );
}

function CurrencyRow({ code, selected, onSelect }) {
  return (
    <li role="option" aria-selected={selected}>
      <button
        type="button"
        onClick={() => onSelect(code)}
        className="w-full flex items-center gap-2 px-2 py-2 rounded-lg hover:bg-surface text-left"
      >
        {flagUrl(code) && (
          <img src={flagUrl(code)} alt="" className="w-5 h-5 rounded-full object-cover" />
        )}
        <span className="font-medium text-sm">{code}</span>
        <span className="text-xs text-muted truncate">{currencyName(code)}</span>
        {selected && (
          <img
            src={`${process.env.PUBLIC_URL}/assets/images/icon-check.svg`}
            alt="Selected"
            className="w-4 h-4 ml-auto"
          />
        )}
      </button>
    </li>
  );
}

export default CurrencyPicker;
