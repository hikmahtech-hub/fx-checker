import React from "react";
import { CURRENCY_INFO } from "../data/currencies";

function Header() {
  const count = Object.keys(CURRENCY_INFO).length;

  return (
    <header className="flex items-center justify-between px-4 sm:px-6 py-4 border-b border-border">
      <img
        src={`${process.env.PUBLIC_URL}/assets/images/logo.svg`}
        alt="FX Checker"
        className="h-6"
      />
      <p className="text-xs text-muted">
        {count} Currencies &middot; EOD &middot; ECB data
      </p>
    </header>
  );
}

export default Header;
