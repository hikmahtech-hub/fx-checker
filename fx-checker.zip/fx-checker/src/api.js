const BASE_URL = "https://api.frankfurter.app";

// GET /latest?from=USD -- all current rates for a base currency
export async function fetchLatestRates(base) {
  const res = await fetch(`${BASE_URL}/latest?from=${base}`);
  if (!res.ok) throw new Error("Could not load live rates.");
  return res.json();
}

// GET /latest?from=USD&to=EUR -- single pair rate
export async function fetchPairRate(from, to) {
  const res = await fetch(`${BASE_URL}/latest?from=${from}&to=${to}`);
  if (!res.ok) throw new Error("Could not load the exchange rate.");
  const data = await res.json();
  return data.rates[to];
}

// GET /{start}..{end}?from=USD&to=EUR -- time series for the rate-history chart
export async function fetchHistory(from, to, startDate, endDate) {
  const res = await fetch(`${BASE_URL}/${startDate}..${endDate}?from=${from}&to=${to}`);
  if (!res.ok) throw new Error("Could not load rate history.");
  const data = await res.json();
  // data.rates is an object keyed by date -> { TO: rate }
  return Object.entries(data.rates)
    .map(([date, rates]) => ({ date, rate: rates[to] }))
    .sort((a, b) => (a.date > b.date ? 1 : -1));
}

// Converts a range key like "1m" into a start date string (YYYY-MM-DD)
export function startDateForRange(range) {
  const now = new Date();
  const d = new Date(now);
  switch (range) {
    case "1d":
      d.setDate(d.getDate() - 5); // Frankfurter has no hourly data; use a few days as a stand-in for "1d"
      break;
    case "1w":
      d.setDate(d.getDate() - 7);
      break;
    case "1m":
      d.setMonth(d.getMonth() - 1);
      break;
    case "3m":
      d.setMonth(d.getMonth() - 3);
      break;
    case "1y":
      d.setFullYear(d.getFullYear() - 1);
      break;
    case "5y":
      d.setFullYear(d.getFullYear() - 5);
      break;
    default:
      d.setMonth(d.getMonth() - 1);
  }
  return d.toISOString().slice(0, 10);
}

export function todayDateString() {
  return new Date().toISOString().slice(0, 10);
}
