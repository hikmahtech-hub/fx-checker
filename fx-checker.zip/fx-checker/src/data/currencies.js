// Maps each currency code supported by the Frankfurter API to a flag image
// (from public/assets/images/flags) and a readable name.
// Frankfurter (ECB) supports a fixed list of ~31 currencies.

export const CURRENCY_INFO = {
  AUD: { name: "Australian Dollar", flag: "au" },
  BGN: { name: "Bulgarian Lev", flag: "bg" },
  BRL: { name: "Brazilian Real", flag: "br" },
  CAD: { name: "Canadian Dollar", flag: "ca" },
  CHF: { name: "Swiss Franc", flag: "ch" },
  CNY: { name: "Chinese Yuan", flag: "cn" },
  CZK: { name: "Czech Koruna", flag: "cz" },
  DKK: { name: "Danish Krone", flag: "dk" },
  EUR: { name: "Euro", flag: "eu" },
  GBP: { name: "British Pound", flag: "gb" },
  HKD: { name: "Hong Kong Dollar", flag: "hk" },
  HUF: { name: "Hungarian Forint", flag: "hu" },
  IDR: { name: "Indonesian Rupiah", flag: "id" },
  ILS: { name: "Israeli Shekel", flag: null },
  INR: { name: "Indian Rupee", flag: "in" },
  ISK: { name: "Icelandic Krona", flag: "is" },
  JPY: { name: "Japanese Yen", flag: "jp" },
  KRW: { name: "South Korean Won", flag: "kr" },
  MXN: { name: "Mexican Peso", flag: "mx" },
  MYR: { name: "Malaysian Ringgit", flag: "my" },
  NOK: { name: "Norwegian Krone", flag: "no" },
  NZD: { name: "New Zealand Dollar", flag: "nz" },
  PHP: { name: "Philippine Peso", flag: "ph" },
  PLN: { name: "Polish Zloty", flag: "pl" },
  RON: { name: "Romanian Leu", flag: "ro" },
  SEK: { name: "Swedish Krona", flag: "se" },
  SGD: { name: "Singapore Dollar", flag: "sg" },
  THB: { name: "Thai Baht", flag: "th" },
  TRY: { name: "Turkish Lira", flag: "tr" },
  USD: { name: "US Dollar", flag: "us" },
  ZAR: { name: "South African Rand", flag: "za" },
};

export const POPULAR_CODES = ["USD", "EUR", "GBP", "JPY", "CAD", "AUD", "CHF", "CNY"];

export function flagUrl(code) {
  const info = CURRENCY_INFO[code];
  if (!info || !info.flag) return null;
  return `${process.env.PUBLIC_URL}/assets/images/flags/${info.flag}.webp`;
}

export function currencyName(code) {
  return CURRENCY_INFO[code]?.name || code;
}
